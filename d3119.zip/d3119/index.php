<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intro</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="left">
            <div class="img">
                <p>Logo</p>
            </div>
            <div class="text">
                <h1>Intro</h1>
                <p1>Same introduction lines  about the website or company</p>
            </div>    
        </div>
        <div class="right">
            <div class="nav">
                <a href="">Link1</a>
                <a href="">Link2</a>
                <a href="">Link3</a>
                <a href="">Link4</a>
                <a href="">Link5</a>
                <a href="">Link</a>
            </div>
        </div>
    </header>
    <main>
        <div class="top">
            <p>Services</p>
            <p>Services</p>
            <p>Services</p>
            <p>Recent Work</p>
            <p>Recent Work</p>
            <p>Recent Work</p>
        </div>
        <div class="bottom">
            <p>Twitter Feed</p>
        </div>
    </main>
    <footer>
        <div class="fleft">
            <a href="#">Link1</a>
            <a href="#">Link2</a>
            <a href="#">Link3</a>
            <a href="#">Link4</a>
            <a href="#">Link5</a>
            <a href="#">Link6</a>
        </div>
        <div class="fright">
            <p>copyNight Into</p>
        </div>
    </footer>
</body>
</html>